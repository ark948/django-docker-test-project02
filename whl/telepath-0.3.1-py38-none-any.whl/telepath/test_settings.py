INSTALLED_APPS = [
    'telepath',
    'django.contrib.staticfiles',
]

SECRET_KEY = 'not needed'
STATIC_URL = '/static/'
