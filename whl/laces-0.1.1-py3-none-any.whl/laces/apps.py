from django.apps import AppConfig


class LacesAppConfig(AppConfig):
    label = "laces"
    name = "laces"
    verbose_name = "Laces"
