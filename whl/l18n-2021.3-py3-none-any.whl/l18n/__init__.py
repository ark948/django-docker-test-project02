from .version import __version__, __version_info__

from .maps import tz_cities, tz_fullnames, territories
from .translation import set_language
