class RemovedInWillow17Warning(DeprecationWarning):
    pass
