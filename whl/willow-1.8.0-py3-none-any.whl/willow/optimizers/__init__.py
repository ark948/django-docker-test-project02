from .cwebp import Cwebp  # noqa: F401
from .gifsicle import Gifsicle  # noqa: F401
from .jpegoptim import Jpegoptim  # noqa: F401
from .optipng import Optipng  # noqa: F401
from .pngquant import Pngquant  # noqa: F401
